#!/bin/bash

zip -r "UIPoC.zip" * -x "UIPoC.zip"